<?php

namespace src;


use src\Messor;

Messor::checkCodeRequest();